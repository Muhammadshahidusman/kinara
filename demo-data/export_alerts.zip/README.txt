Kinara export: candidate alerts (GeoJSON, EPSG:4326)
Exported 2026-11-06 06:52 UTC

Floodplain: Floodplain (HAND proxy) (243.3 km2)
Exposure built: 2026-11-03T07:55:19+00:00

Fields:
  alert_id: K-<year>-<sequence>
  status: new, visited, confirmed, false_alarm, no_access
  first_detected: Date of the Sentinel-1 pass that completed the persistence rule
  last_seen: Latest pass that detected it again
  area_ha: Area, hectares (UTM 43N)
  area_kanal: Area, revenue kanal (20 marla x 272.25 sq ft)
  mouza: Mouza by majority overlap
  tehsil: Tehsil by majority overlap
  distance_river_m: Distance to the Ravi centreline (HydroSHEDS), m
  flooded_2025: At least 10% of the alert inside the Aug 2025 flood extent
  rise_db: Mean of the smallest per-pass VV rise over the baseline, dB
  orbit: Sentinel-1 relative orbit

Candidate alerts come from 10 m satellite data and must be verified on site. Kinara does not
judge legality. All counts are area-level planning estimates, not household records.
Open data: Copernicus Sentinel-1/-2, Google Open Buildings (CC BY 4.0 / ODbL), MERIT Hydro,
HydroSHEDS, WorldPop (CC BY 4.0).