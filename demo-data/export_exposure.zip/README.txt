Kinara export: exposure by unit
Exported 2026-11-06 06:52 UTC

Floodplain: Floodplain (HAND proxy) (243.3 km2)
Exposure built: 2026-11-03T07:55:19+00:00

Fields:
  unit_id: Unit id (T- tehsil, M- mouza, fp_ zone)
  unit_type: zone, tehsil or mouza
  name: Name (official boundary attribute)
  name_ur: Urdu name (mouza layer)
  tehsil: Tehsil of the mouza (official tehsil layer, majority overlap)
  n_tehsils: Official tehsils the mouza polygon crosses (above 1 = the boundary layers disagree)
  area_km2: Area of the unit INSIDE the floodplain, km2 (UTM 43N)
  bld_n: Estimated buildings: Open Buildings v3 footprints, confidence >= 0.75
  bld_post2016_n: Footprints first seen 2017-2023 (Open Buildings 2.5D Temporal, presence >= 0.5)
  bld_year_unknown_n: Footprints with no year in the temporal data
  bld_flooded_2025: Footprints inside the Aug 2025 Sentinel-1 flood extent (see summary for calibration status)
  pop_est: Estimated population (rounded to 10)
  pop_source: Population dataset and year

Candidate alerts come from 10 m satellite data and must be verified on site. Kinara does not
judge legality. All counts are area-level planning estimates, not household records.
Open data: Copernicus Sentinel-1/-2, Google Open Buildings (CC BY 4.0 / ODbL), MERIT Hydro,
HydroSHEDS, WorldPop (CC BY 4.0).